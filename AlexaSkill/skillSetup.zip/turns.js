module.exports = { //turn list
	"left": "The car is turning left.",
    "right": "The car is turning right."
};
module.exports = { //direction list
    "stop": "The car is stopping."
};







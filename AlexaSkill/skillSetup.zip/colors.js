module.exports = { //light color list
    "green": "The car's lights are now green.",
	"red": "The car's lights are now red.",
	"blue": "The car's lights are now blue.",
	"orange": "The car's lights are now orange.",
	"yellow": "The car's lights are now yellow."
};
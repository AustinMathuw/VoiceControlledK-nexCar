module.exports = { //direction list
    "straight": "The car is going straight.",
	"forward": "The car is moving forward.",
	"backward": "The car is moving backward.",
	"reverse": "The car is going in reverse.",
	"back": "The car is moving backward."
};






